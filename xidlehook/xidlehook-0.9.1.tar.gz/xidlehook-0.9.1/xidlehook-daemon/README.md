# xidlehook(-daemon)

This is the main `xidlehook` application. It's somewhat a subject of
feature creep unfortunately, but that also makes it fairly flexible,
enough for most people. Most contributions of xidlehook may should
probably go here, unless it's in one of the standard modules or other
core internals.

If you're dissatisfied with the API of xidlehook-daemon, think twice
whether or not you really want to rely on this client or whether you
want to unleash the full flexibility of the inner workings by making
your own client for it, in the `xidlehook-core` repository.
